TOKEN='5675820615:AAGwVb_vfahix5vfmFVpPE6aVODTpwqQcUo'
ADMINS = [5719814852]

bot_username = 'sadasadbot'

minimalka = 100 #мин пополнение
maximalka = 20000 #макс пополнение

vxodadmin='Админ' #Слово для входа в админ панель (Доступно только для админов)
vxodworker='воркер'#Слово для входа в воркер панель (Доступно только для всех)

zalety = -1001446363665 #фйди канала залётов

poderjka = "" #аккаунт техподдержки без @

maxpromo = 1000 #максимальная сумма промокода которую могут создать воркеры

#https://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhackerhttps://t.me/Fertyhacker